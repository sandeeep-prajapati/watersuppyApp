<!doctype html>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>User Login</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
<?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                    
                    <?php endif; ?>
                    <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                    <?php endif; ?>
    <div class="container register register-background custBack">
        <div class="row ">
            <h1 class="text-warning text-center pt-4"><b>Vender Login Page</b></h1>
            <div class="col-md-1">
            </div>
            <div class="col-md-4" style="padding-top: 100px;">
                <img src="img/red-rocket-png-5.png" alt="">
                <h2 class="">Here you can supply water bottles to user</h2>
                <p class="">if you have not registered yet kindly contact to addministrator Sandeep Prajapati contact no : +916392424180</p>
            </div>
            <div class="col-md-1">
            </div>
            <div class="col-md-6 mb-5 register-right">
                <form action="/vlogin" method="post">
                    <?php echo csrf_field(); ?>
                    <br>
                    <br>
                    <Label class="p-1">ENTER YOUR USER NAME</Label>
                    <br>
                    <input class="form-control  p-2" type="text" name="username" placeholder="User Name" value="<?php echo e(old('username')); ?>">
                    <span style="color : red"><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    <br>
                    <Label class="p-1">ENTER PASSWORD</Label>
                    <br>
                    <input class="form-control  p-2" type="password" name="password" placeholder="PASSWORD" value="<?php echo e(old('password')); ?>">
                    <span style="color : red"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    <br>
                    <br>
                    <input class="form-control bg-success p-2 text-white btn" type="submit" value="Login Now">
                </form>
            </div>
        </div>
    </div>

    <div class="p-4"></div>
    <!-- footer start -->
  <?php echo $__env->make('userviews.maincomponents.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- footer end -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>
</html>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
</body>

</html><?php /**PATH G:\xampp\htdocs\watersupply\resources\views/vender/login.blade.php ENDPATH**/ ?>