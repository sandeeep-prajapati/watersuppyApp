<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>New User Registration</title>
    <link rel="stylesheet" href="style2.css">
</head>

<body onload="getCurrentLocation()">


    <div class="container register register-background custBack">
        <!-- nav-bar start -->
        <?php echo $__env->make('userviews.maincomponents.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- nav-bar end -->
        <div class="container">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>

            <?php endif; ?>
            <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
            <?php endif; ?>
        </div>

        <div class="row p-4">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <img src="<?php echo e($d->img); ?>" style="width:100%; height: auto;" alt="" srcset="">
                <a href="\editimg?id=<?php echo e($id); ?>"><button class="btn btn-sm bg-success text-white">Change Profile Image</button></a>
            </div>
            <div class="col-md-8 col-md-6">
                <h1 class="text-center">Hello <?php echo e($d->name); ?> 👋 you can edit now</h1>
                <form action="<?php echo e(url('editme')); ?>" enctype='multipart/form-data' method="POST">
                    <?php echo csrf_field(); ?>
                    <input class="form-control p-2" type="number" style="display:none;" name="id" placeholder="eg : Mr Mark Zuckerberg" value="<?php echo e($id); ?>">                       
                    <Label class="p-1">Enter Your Full Name</Label>
                    <br>
                    <input class="form-control p-2" type="text" name="name" placeholder="eg : Mr Mark Zuckerberg" value="<?php echo e($d->name); ?>">                       
                    <span style="color : red"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    <br>
                    <input class="form-control p-2" style="display: none;" type="text" name="img" value="<?php echo e($d->img); ?>" placeholder = "choose image">
                    <Label class="p-1">ENTER YOUR Contact No</Label>
                    <br>
                    <input class="form-control p-2" type="number" name="contactNo" placeholder="eg : 639242XXXX" value="<?php echo e($d->contactNo); ?>">
                    <span style="color : red"><?php $__errorArgs = ['contactNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    <br>
                    <Label class="p-1 ">Create Strong Password</Label>
                    <br>
                    <input class="form-control p-2" type="password" name="password" placeholder="PASSWORD" value="<?php echo e($d->password); ?>">
                    <span style="color : red"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    <br>
                    <Label class="p-1 ">Enter your address</Label>
                    <br>
                    <input class="form-control p-2" type="text" name="address" placeholder="eg : Sector 5 Gida Gorkhpur" value="<?php echo e($d->address); ?>">
                    <span style="color : red"><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    <br>
                    <input class="form-control bg-success p-2 text-white btn" type="submit" value="Save Changes">
                </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        


    </div>


    <!-- footer -->
    <div class="p-4"></div>
    <!-- footer start -->
  <?php echo $__env->make('userviews.maincomponents.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- footer end -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>

</html>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH G:\xampp\htdocs\watersupply\resources\views\userviews\dashboard\editprofile.blade.php ENDPATH**/ ?>