<!doctype html>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>User Login</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
<?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                    
                    <?php endif; ?>
                    <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                    <?php endif; ?>
    <div class="container register register-background custBack">
        <div class="row ">
            <h1 class="text-center text-warning p-4">All active orders</h1>
            <?php $__currentLoopData = $data0; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6" >
                        <div class="card">
                            <!-- <img src="<?php echo e($d1->img); ?>" class="card-img-top" alt="Profile image"> -->
                            <iframe src="https://google.com/maps?q=<?php echo e($d1->latitude); ?>,<?php echo e($d1->longitude); ?>&h1=es;z=14&output=embed" style="width: 100%; height: 300px;"></iframe>
                            <div class="card-body">
                                <h5 class="card-title"><b>Name : <?php echo e($d1->name); ?></b></h5>
                                <h5 class="card-title"><b>Address : <?php echo e($d1->address); ?></b></h5>
                                <h5 class="card-title">Amount : <?php echo e($d1->amout); ?></h5>
                                <h5 class="card-title">Contact No : <?php echo e($d1->contactNo); ?></h5>
                                <h5 class="card-title">Alternet Contact No : <?php echo e($d1->contactNo); ?></h5>
                                <p class="card-text">These are all record will be shown to vender, if any thing wrong you can change it to edit prifile section. you can delete this record after getting fresh water water</p>
                                <?php if($d1->status == 0): ?>
                                <a href="/comming?id=<?php echo e($d1->order_id); ?>" class="btn btn-info">On the way</a>
                                <a href="/delivered?id=<?php echo e($d1->order_id); ?>" class="btn btn-success">Delivered</a>
                                <?php endif; ?>
                                <?php if($d1->status == 1): ?>
                                <a href="/cancel?id=<?php echo e($d1->order_id); ?>" class="btn btn-danger">Cancel</a>
                                <a href="/delivered?id=<?php echo e($d1->order_id); ?>" class="btn btn-success">Delivered</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
        <h1 class="text-center text-primary p-4">Some one going for delivery</h1>
        <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6" >
                        <div class="card">
                            <!-- <img src="<?php echo e($d1->img); ?>" class="card-img-top" alt="Profile image"> -->
                            <iframe src="https://google.com/maps?q=<?php echo e($d1->latitude); ?>,<?php echo e($d1->longitude); ?>&h1=es;z=14&output=embed" style="width: 100%; height: 300px;"></iframe>
                            <div class="card-body">
                                <h5 class="card-title"><b>Name : <?php echo e($d1->name); ?></b></h5>
                                <h5 class="card-title"><b>Address : <?php echo e($d1->address); ?></b></h5>
                                <h5 class="card-title">Amount : <?php echo e($d1->amout); ?></h5>
                                <h5 class="card-title">Contact No : <?php echo e($d1->contactNo); ?></h5>
                                <h5 class="card-title">Alternet Contact No : <?php echo e($d1->contactNo); ?></h5>
                                <p class="card-text">These are all record will be shown to vender, if any thing wrong you can change it to edit prifile section. you can delete this record after getting fresh water water</p>
                                <?php if($d1->status == 0): ?>
                                <a href="/comming?id=<?php echo e($d1->order_id); ?>" class="btn btn-info">On the way</a>
                                <a href="/delivered?id=<?php echo e($d1->order_id); ?>" class="btn btn-success">Delivered</a>
                                <?php endif; ?>
                                <?php if($d1->status == 1): ?>
                                <a href="/cancel?id=<?php echo e($d1->order_id); ?>" class="btn btn-danger">Cancel</a>
                                <a href="/delivered?id=<?php echo e($d1->order_id); ?>" class="btn btn-success">Delivered</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
        <h1 class="text-center text-success p-4">Successfully delivery</h1>
        <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6" >
                        <div class="card">
                            <!-- <img src="<?php echo e($d1->img); ?>" class="card-img-top" alt="Profile image"> -->
                            <iframe src="https://google.com/maps?q=<?php echo e($d1->latitude); ?>,<?php echo e($d1->longitude); ?>&h1=es;z=14&output=embed" style="width: 100%; height: 300px;"></iframe>
                            <div class="card-body">
                                <h5 class="card-title"><b>Name : <?php echo e($d1->name); ?></b></h5>
                                <h5 class="card-title"><b>Address : <?php echo e($d1->address); ?></b></h5>
                                <h5 class="card-title">Amount : <?php echo e($d1->amout); ?></h5>
                                <h5 class="card-title">Contact No : <?php echo e($d1->contactNo); ?></h5>
                                <h5 class="card-title">Alternet Contact No : <?php echo e($d1->contactNo); ?></h5>
                                <p class="card-text">These are all record will be shown to vender, if any thing wrong you can change it to edit prifile section. you can delete this record after getting fresh water water</p>
                                <?php if($d1->status == 0): ?>
                                <a href="/comming?id=<?php echo e($d1->order_id); ?>" class="btn btn-info">On the way</a>
                                <a href="/delivered?id=<?php echo e($d1->order_id); ?>" class="btn btn-success">Delivered</a>
                                <?php endif; ?>
                                <?php if($d1->status == 1): ?>
                                <a href="/cancel?id=<?php echo e($d1->order_id); ?>" class="btn btn-danger">Cancel</a>
                                <a href="/delivered?id=<?php echo e($d1->order_id); ?>" class="btn btn-success">Delivered</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="p-4"></div>
    <!-- footer start -->
  <?php echo $__env->make('userviews.maincomponents.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- footer end -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>
</html>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
</body>

</html><?php /**PATH G:\xampp\htdocs\watersupply\resources\views\vender\dashboard.blade.php ENDPATH**/ ?>