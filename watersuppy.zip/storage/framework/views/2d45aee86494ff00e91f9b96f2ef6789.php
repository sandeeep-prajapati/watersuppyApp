<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>New User Registration</title>
    <link rel="stylesheet" href="style2.css">
</head>

<body onload="getCurrentLocation()">


    <div class="container register register-background custBack">
        <!-- nav-bar start -->
        <?php echo $__env->make('userviews.maincomponents.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- nav-bar end -->
        <div class="container">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>

            <?php endif; ?>
            <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
            <?php endif; ?>
        </div>

        <div class="row p-4">
            <div class="col-md-3 col-sm-2"></div>
            <div class="col-md-6 col-md-8" style="padding-bottom: 200px;">
                <h1 class="text-center">Pick image for profile image</h1>
                <form action="<?php echo e(url('changeImage')); ?>" enctype='multipart/form-data' method="POST">
                    <br>
                    <?php echo csrf_field(); ?>
                    <input type="number" class="form-control" style="display: none;" value="<?php echo e($id); ?>">  
                    <label for="change_image">Change Profile image</label>
                    <input type="file" name='img' class="form-control" placeholder="choose image">
                    <br>
                    <button type="submit" class="btn form-control btn-success">Change Image</button>
                </form>
            </div>
            <div class="col-md-3 col-sm-2"></div>
        </div>

        


    </div>


    <!-- footer -->
    <div class="p-4"></div>
    <!-- footer start -->
  <?php echo $__env->make('userviews.maincomponents.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- footer end -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>

</html>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH G:\xampp\htdocs\watersupply\resources\views/userviews/dashboard/changeimg.blade.php ENDPATH**/ ?>